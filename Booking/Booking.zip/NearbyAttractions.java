import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;
import static java.lang.Math.*;
import java.text.DecimalFormat;

public class NearbyAttractions {
	static public void main(String []args){
		Scanner s = new Scanner(System.in);
		int N = s.nextInt();
		Attraction []attractions = new Attraction[N];
		for(int i = 0; i<N ;i++){
			attractions[i] = new Attraction(s.nextInt(),s.nextDouble(),s.nextDouble());
			// System.out.println(attractions[i].toString());
		}
		int M = s.nextInt();
		Case []cases = new Case[M];
		for(int i = 0; i<M; i++){
			cases[i] = new Case(s.nextDouble(),s.nextDouble(),s.next(),s.nextInt());
			resolve(attractions,cases[i]);
		}
		
	}
	static public void resolve(Attraction []attractions, Case c){
		// System.out.println(c.toString());
		PriorityQueue<Tuple> res = new PriorityQueue<Tuple>();
		for(int i = 0; i<attractions.length; i++){
			Attraction a = attractions[i];
			Tuple t = c.getTuple(a);
			if(t.feasible){
				res.add(t);
			}
		}
		StringBuilder b = new StringBuilder();
		while(!res.isEmpty()){
			b.append(res.poll().attraction.id);
			b.append(" ");
			// System.out.print(res.poll().attraction.id + " ");
		}
		System.out.println(b.toString().trim());
	}
}

class Attraction {
	int id;
	Point p;
	double latitude;
	double longitude;
	public Attraction(int id, double lat, double lon){
		this.id = id;
		this.p = new Point(lat,lon);
	}
	public String toString(){
		return "[" + id + "] " + p.toString();
	}
}

class Tuple implements Comparable{
	double distance;
	Attraction attraction;
	boolean feasible;
	public Tuple(double d, Attraction a, boolean f){
		this.distance = d;
		this.attraction = a;
		this.feasible = f;
	}
	public int compareTo(Object o){
		if(o instanceof Tuple){
			Tuple to = (Tuple) o;
			if(distance > to.distance){
				return 1;
			} else 	if(distance < to.distance){
				return -1;
			} else {
				return attraction.id - to.attraction.id;
			}
		} else {
			return 0;
		}
	}
}

class Case {
	Point p;
	String transport;
	int maxMinutes;
	public Case(double lat, double lon, String tr, int max){
		this.p = new Point(lat,lon);
		this.transport = tr;
		this.maxMinutes = max;
	}
	public String toString(){
		return p.toString() + " " + transport + " " + maxMinutes;
	}
	public Tuple getTuple(Attraction a){
		try {
			double d = p.distance(a.p);
			return new Tuple(d,a,getSpeed(transport) * maxMinutes >= d);
		} catch (Exception e){
			return null;
		}
	}

	// return speed in meters/min
	public double getSpeed(String s) throws Exception {
		switch(s) {
			case "metro" : return 20.0 * 1000.0 / 60.0;
			case "bike" : return 15.0 * 1000.0 / 60.0;
			case "foot" : return 5.0 * 1000.0 / 60.0;
			default : throw new Exception("Unknown transport");
		}
	}
}

class Point {

	final static double EARTH_RADIUS = 6371000.0;// [m]
	final static DecimalFormat df2 = new DecimalFormat("###.##");

	double latitude;
	double longitude;

	public Point(double lat, double lon){
		this.latitude = lat;
		this.longitude = lon;
	}
	public String toString(){
		return "(" + latitude + ", " + longitude + ")";
	}

	public double distance(Point p){
		double point1_lat_in_radians = toRadians(this.latitude);
		double point2_lat_in_radians = toRadians(p.latitude);
		double point1_long_in_radians = toRadians(this.longitude);
		double point2_long_in_radians = toRadians(p.longitude);

		return Double.valueOf(df2.format(acos( sin( point1_lat_in_radians ) * sin( point2_lat_in_radians ) +
			cos( point1_lat_in_radians ) * cos( point2_lat_in_radians ) *
			cos( point2_long_in_radians - point1_long_in_radians) ) * EARTH_RADIUS));
	}
}